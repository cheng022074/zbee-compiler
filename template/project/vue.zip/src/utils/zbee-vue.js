const exports = {},
    prefixRe = /^[^\:]+\:{2}/,
    defaultPrefix = 'src',
    usedCodes = {};

export function include(name) {

    if (usedCodes.hasOwnProperty(name)) {

        return usedCodes[name];
    }

    if (prefixRe.test(name)) {

        return usedCodes[name] = exports[name];
    }

    return usedCodes[name] = exports[`${defaultPrefix}::${name}`];
}

export function exists(name) {

    return exports.hasOwnProperty(name);
}

exports['ue::sample.Button'] = function(button) {

    const {
        $alert: alert,
        $confirm: confirm,
        $prompt: prompt
    } = this;









    /**
     * 
     * @param {ViewModel} button 按钮
     * 
     */



    button.document.find('text', 'Hello').set('type', 'primary');
};
exports['ue::sample.event.ClickMe'] = function(button) {

    const {
        $alert: alert,
        $confirm: confirm,
        $prompt: prompt
    } = this;









    /**
     * 
     * @param {ViewModel} button 点击的按钮
     * 
     */

    alert('Hello ZBEE');
};
exports['ue::sample.event.group.Click'] = function(buttonGroup, button) {

    const {
        $alert: alert,
        $confirm: confirm,
        $prompt: prompt
    } = this;









    /**
     * 
     * @param {ViewModel} buttonGroup 点击的按钮组
     * 
     * @param {ViewModel} button 点击的按钮
     * 
     */

    alert(`点击了 ${button.get('text')} 按钮`);
};
exports['ue::sample.model.view.ClickMe'] = function(button) {

    const {
        $alert: alert,
        $confirm: confirm,
        $prompt: prompt
    } = this;









    /**
     * 
     * @param {ViewModel} button 点击的按钮
     * 
     */

    button.document.find('control', 'buttongroup').set('type', 'primary');
};
exports['ue::sample.Welcome'] = function(button, query) {

    const {
        $alert: alert,
        $confirm: confirm,
        $prompt: prompt
    } = this;









    /**
     * 
     * @param {ViewModel} button 点击的按钮
     * 
     * @param {Object} query 查询参数
     * 
     */

    alert('欢迎使用 ZBEE Element UI 开发系统');

    console.log(query);
};

export default exports;