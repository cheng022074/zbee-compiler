import {
    include
} from '~/utils/zbee-vue' ;

import {
    include as include2
} from '~/../lib/zbee';

export default function(component , listener , ...args){

    if(listener){

        let target = include(`ue::${listener}`) ;
    
        if(include2('is.function')(target)){
    
            target.call(component , ...args) ;
        }
    }
}