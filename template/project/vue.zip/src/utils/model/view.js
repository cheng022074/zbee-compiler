/**
 * 
 * 视图模型对象设计
 * 
 */

 import {
     include
 } from '~/../lib/zbee' ;

 import {
     include as include2,
     exists
 } from '~/utils/zbee-vue';

 const VIEW_MODELS = new Map(),
       isObject = include('is.object.simple'),
       find = include('object.find'),
       findAll = include('object.find.all');

 import Vue from 'vue' ;

export default class ViewModel{

    static init(data){

        include('object.forEach')(data , item =>{

            if(item.hasOwnProperty('control')){

                // 执行默认值附加

                // 解决双向绑定时数据无法实时传递的问题
            }

        }) ;
    }

    /**
     * 
     * 通过一个 Vue 的组件对象获得一个视图模型
     * 
     * @param {VueComponent} component Vue 组件对象
     * 
     * @return {ViewModel}
     * 
     */

    static get(viewModel , rootViewModel){

        if(!VIEW_MODELS.has(viewModel)){

            VIEW_MODELS.set(viewModel , new ViewModel(viewModel , rootViewModel)) ;
        }

        return VIEW_MODELS.get(viewModel) ;
    }

    static unregister(viewModel){

        if(VIEW_MODELS.has(viewModel)){

            VIEW_MODELS.delete(viewModel) ;

            return true ;
        }

        return false ;
    }

    constructor(data , document){

        let me = this ;

        me.data = data ;

        me.$document = document ;
        
    }

    get document(){

        let me = this,
            document = me.$document ;

        if(document){

            return ViewModel.get(document) ;
        
        }else{

            return me ;
        }
    }

    set(name , value){

        let data = this.data ;

        if(data){

            if(isObject(name)){

                let keys = Object.keys(name) ;

                for(let key of keys){

                    Vue.set(data , key , name[key]) ;
                }

            }else{

                Vue.set(data , name , value) ;
            }
        }
    }

    has(name){

        return name in this.data ;
    }

    get(name){

        let data = this.data ;

        if(data){

            return data[name] ;
        }
    }

    find(name , value){

        let me = this ;

        let model = find(me.data , name , value) ;

        if(model){

            return ViewModel.get(model , me.document.data) ;
        }
    }

    findAll(name , value){

        let root = me.document.data ;

        return findAll(this.data , name , value).map(model => ViewModel.get(model , root)) ;
    }

    load(query , data){

        this.findAll(query).forEach(model => {

            if(model.has('control')){

                let name = `data.load.${model.get('control')}` ;

                if(exists(name)){

                    include2(name)(model , data) ;
                }

            }else{

                include2('data.load')(model , data) ;
            }

        }) ;
    }

    extract(query){

        let result = {},
            {
                assign
            } = Object;

        this.findAll(query).forEach(model =>{

            if(model.has('control')){

                let name = `data.extract.${model.get('control')}` ;

                if(exists(name)){

                    assign(result , include2(name)(model)) ;
                }

            }else{

                assign(result , include2('data.extract')(model)) ;
            }

        }) ;

        return result ;
    }
}