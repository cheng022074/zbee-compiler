<template>
    <zb-page>
        <el-tabs>
            <el-tab-pane label="界面">
                <zb-samplepage :zb-view-model="ui" :zb-root-view-model="ui" :blocks="ui.blocks">
                </zb-samplepage>
            </el-tab-pane>
            <el-tab-pane label="代码">
                <pre v-highlightjs>
                    <code class="javascript">{{desc}}</code>
                </pre>
            </el-tab-pane>
        </el-tabs>
    </zb-page>
</template>
<script>

import Sample from '~/../ui/sample/model/View' ;

export default {

    data(){

        return {
            ui:Sample,
            desc:JSON.stringify(Sample , null , 2)
        } ;
    }
} ;

</script>