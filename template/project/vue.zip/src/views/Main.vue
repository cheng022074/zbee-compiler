<template>
    <el-container class="viewport">
        <el-aside width="200px">
            <zb-menu :menu="menu">
            </zb-menu>
        </el-aside>
        <el-main>
            <router-view></router-view>
        </el-main>
    </el-container>
</template>
<script>

    import {
        getMenu
    } from './Main' ;

    export default{

        data(){

            return {
                menu:getMenu()
            } ;
        }

    } ;

</script>
<style>
    .viewport{
        height: 100%;
    }
</style>