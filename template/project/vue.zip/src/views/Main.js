const ROUTER = require('~/../config/browser/router') ;

export function getMenu(){

    let config = ROUTER['/main'].children,
        urls = Object.keys(config),
        result = [];

    for(let url of urls){

        let {
            title
        } = config[url] ;

        result.push({
            url:`/main/${url}`,
            title
        }) ;
    }

    return result ;
}