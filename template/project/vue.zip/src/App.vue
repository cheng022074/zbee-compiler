<template>
  <div id="app">
      <router-view></router-view>
  </div>
</template>
<style>
html,body{
  overflow: hidden;
  height:100%;
  width: 100%;
  position: relative;
}
#app {
  position: inherit;
  height: inherit;
  font-family: Helvetica, sans-serif;
}
</style>
