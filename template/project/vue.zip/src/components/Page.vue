<script>

import Page from './Page' ;

export default new Page().toJSON() ;

</script>
<style scoped>
    .zb-page{
        overflow: auto;
        height:100%;
    }
</style>