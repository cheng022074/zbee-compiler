function onInput(value){
    
    this.$emit('input' , value) ;
}

export default class {
    static get config(){

        return {
            props:[
                'value'
            ],
        
            methods:{
                onInput
            }
        } ;
    }
} ;