import {
    include
} from '~/../lib/zbee' ;

const from = include('array.from');

import Component from './Component' ;

export default class Container extends Component{


    generateProperties(){

        return [{
            name:'items',
            default:[]
        }] ;
    }

    static renderItem(createElement , item , rootViewModel){

        let {
            control,
            ...props
        } = item ;

        props.zbViewModel = item ;

        props.zbRootViewModel = rootViewModel ;

        if(control){

            return createElement(`zb-${control}` , {
                props
            }) ;
        }

        return createElement('div') ;
    }

    static render(component , createElement , itemsName = 'items' , cls = 'zb-container'){

        let {
            zbRootViewModel
        } = component,
        items = from(component[itemsName]);

        if(items.length === 0){

            return createElement('div' , {
                attrs:{
                    class:cls
                }
            }  , component.$slots.default) ;
        }

        return createElement('div' , {
            attrs:{
                class:cls
            }
        } , items.map(item =>{

            return Container.renderItem(createElement , item , zbRootViewModel) ;

        })) ;
    }

    render(createElement){

       return Container.render(this , createElement) ;
    }
}