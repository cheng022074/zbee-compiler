<template>
    <el-input type="textarea" autosize :value="value" @input="onInput"></el-input>
</template>
<script>

import Text from '../text' ;

export default Text.config ;

</script>