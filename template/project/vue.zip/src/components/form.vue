<script>

import Config from './form' ;

export default Config ;

</script>

<style scoped src="./form.css"></style>
