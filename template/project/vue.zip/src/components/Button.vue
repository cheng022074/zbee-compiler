<script>

    import Button from './Button' ;

    export default new Button().toJSON() ;
</script>
