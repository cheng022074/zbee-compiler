<script>

    import SamplePage from './Sample' ;

    export default new SamplePage().toJSON() ;

</script>