import {
    include
} from '~/../lib/zbee' ;

const from = include('array.from');

import Page from '../Page' ;

import Container from '../Container' ;

class SamplePage extends Page{

    render(createElement){
        
        let me = this,{
            blocks,
            zbRootViewModel
        } = me ;

        blocks = from(blocks) ;

        if(blocks.length === 0){

            return createElement('div' , {
                attrs:{
                    class:'zb-page'
                }
            } , me.$slots.default) ;
        }

        return createElement('div' , {
            attrs:{
                class:'zb-page'
            }
        } , blocks.map(block =>{

            return createElement('el-container' , [
                createElement('el-header' , [
                    createElement('h3' , block.title)
                ]),
                createElement('el-main' , from(block.items).map(item =>{

                    return Container.renderItem(createElement , item , zbRootViewModel) ;

                }))
            ]) ;

        })) ;
    }
}

export default SamplePage ;