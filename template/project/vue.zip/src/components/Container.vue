<script>

import Container from './Container' ;

export default new Container().toJSON() ;

</script>