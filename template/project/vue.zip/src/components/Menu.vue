<style scoped>
    .zb-menu{
        min-height: 100%;
    }
</style>
<script>
    import Menu from './Menu' ;

    export default Menu ;

</script>   