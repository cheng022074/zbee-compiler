const props = [
    'title',
    'fields',
    'buttons'
] ;

function render(createElement , data , fieldElements = []){
    
    let items = [],
        {
            title,
            buttons
        } = data;

    if(title){

        items.push(createElement('el-header' , [
            createElement('h3' , title)
        ])) ;
    }

    items.push(createElement('el-main' , [
        createElement('el-form' , {
            props:{
                'label-width':'80px'
            }
        } , fieldElements)
    ])) ;

    if(buttons){

        let buttonEls = [] ;

        for(let button of buttons){

            let {
                text,
                disabled
            } = button ;

            buttonEls.push(createElement('el-button' , {
                props:{
                    type:'primary',
                    disabled
                },
                domProps:{
                    innerHTML:text
                }
            })) ;            
        }

        items.push(createElement('el-footer' , buttonEls)) ;
    }

    return createElement('el-container' , items) ;
}

function createItem(createElement , field){

    let {
        control,
        label,
        required,
        hint
    } = field ;

    return createElement('el-form-item' , {
        props:{
            label,
            required
        }
    } , [
        createElement(`zb-${control}` , {
            props:field
        })
    ]) ;
}

function createItems(createElement , fields){

    let items = [] ;

    for(let field of fields){

        items.push(createItem(createElement , field)) ;
    }

    return items ;
}

function createColumnItems(createElement , count , fields){

    let rows = [],
        len = fields.length,
        cols,
        span = 24 / count;

    for(let i = 0 ; i < len ; i ++){

        let modulo = (i + 1) % count ;

        if(modulo === 1){

            cols = [] ;
        }

        cols.push(createElement('el-col' , {
            props:{
                span
            }
        } , [
            createItem(createElement , fields[i])
        ])) ;

        if(modulo === 0){

            rows.push(createElement('el-row' , cols)) ;

            cols = [] ;
        }
    }

    if(cols.length){

        rows.push(createElement('el-row' , cols)) ;
    }

    return rows ;
}

export const simple = {
    props,
    render:function(createElement){

        let me = this ;

        return render(createElement , me , createItems(createElement , me.fields || [])) ;
    }
} ;

export default {
    props,
    render:function(createElement){

        let me = this ;

        return render(createElement , me , createColumnItems(createElement , 2 , me.fields || [])) ;
    }
} ;