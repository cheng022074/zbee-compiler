import Container from './Container' ;

import {
    include
} from '~/../lib/zbee' ;

import ViewModel from '~/utils/model/view' ;

import dispatch from '~/utils/model/view/event/dispatch' ;

const from = include('array.from') ;

export default class Page extends Container{

    generateProperties(){

        return [{
            name:'blocks',
            default:[]
        },
        'onload'] ;
    }

    render(createElement){

       return Container.render(this , createElement , 'blocks' , 'zb-page') ;
    }

    created(){

        let me = this,
        {
            onload,
            zbViewModel,
            zbRootViewModel
        } = me ;

        dispatch(me , onload , ViewModel.get(zbViewModel , zbRootViewModel) , this.$route.query) ;
    }
}