import dispatch from '~/utils/model/view/event/dispatch' ;

import Component from './Component' ;

import ViewModel from '~/utils/model/view' ;

export class EventButton extends Component{

    generateProperties(){

        return [
            'onclick'
        ] ;
    }
}

export class TextButton extends EventButton{

    generateProperties(){

        let properties = super.generateProperties() ;

        properties.push('text') ;

        return properties ;
    }
}

export default class Button extends TextButton{

    generateProperties(){

        let properties = super.generateProperties() ;
        
        properties.push(
            'icon',
            'type',
            'disabled',
            'plain',
            'round',
            'loading',{
                name:'iconAlign',
                default:'left'
            }
        ) ;

        return properties ;
    }

    render(createElement){

        let me = this,{
            icon,
            disabled,
            iconAlign,
            text,
            type,
            loading,
            round,
            plain,
            onclick,
            zbViewModel,
            zbRootViewModel
        } = me,
        children = [
            me.$slots.default || text
        ];

        if(icon && iconAlign === 'right'){

            children.push(createElement('i' , {
                'class':{
                    [icon]:true,
                    'el-icon--right':true
                }
            })) ;
        }

        return createElement('el-button' , {
            props:{
                loading,
                plain,
                type,
                disabled,
                round,
                icon:iconAlign === 'left' ? icon : undefined
            },
            on:{
                click(){

                    let vm = ViewModel.get(zbViewModel , zbRootViewModel) ;
                    
                    dispatch(me , onclick , vm) ;

                    me.$emit('click' , vm) ;
                }
            }
        } , children) ;
    }
}