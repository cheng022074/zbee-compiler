import {
    include
} from '~/../lib/zbee' ;

const copy = include('object.copy') ;

import Button from '../Button' ;

import ViewModel from '~/utils/model/view' ;

import dispatch from '~/utils/model/view/event/dispatch' ;

export default class ButtonGroup extends Button{

    generateProperties(){

        let properties = super.generateProperties() ;

        properties.push({
            name:'buttons',
            default:[]
        }) ;

        return properties ;
    }

    render(createElement){
        
        const {
            assign
        } = Object ;

        let me = this,
            {
                disabled,
                type,
                round,
                plain,
                onclick,
                buttons,
                zbViewModel,
                zbRootViewModel
            } = me;

        return createElement('el-button-group' , buttons.map(button =>{

            return createElement('zb-button' , {
                props:assign({
                    disabled,
                    type,
                    round,
                    plain,
                    zbViewModel:button,
                    zbRootViewModel
                } , button),
                on:{
                    click(button){

                        dispatch(me , onclick , ViewModel.get(zbViewModel , zbRootViewModel) , button) ;
                    }
                }
            }) ;

        })) ;
    }
}