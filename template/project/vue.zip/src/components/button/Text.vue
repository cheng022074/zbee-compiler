<template>
    <zb-button type="text" :zb-view-model="zbViewModel" :zb-root-view-model="zbRootViewModel" :onclick="onclick">{{text}}</zb-button>
</template>
<script>

import {
    TextButton
} from '../Button' ;

export default new TextButton().toJSON() ;

</script>