<template>
    <zb-button icon="el-icon-success" type="primary" :zb-view-model="zbViewModel" :zb-root-view-model="zbRootViewModel" :onclick="onclick">保存</zb-button>
</template>
<script>

import {
    EventButton
} from '../Button' ;

export default new EventButton().toJSON() ;


</script>