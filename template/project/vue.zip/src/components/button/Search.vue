<template>
    <zb-button icon="el-icon-search" type="primary" :zb-view-model="zbViewModel" :zb-root-view-model="zbRootViewModel" :onclick="onclick">查询</zb-button>
</template>
<script>

import {
    EventButton
} from '../Button' ;

export default new EventButton().toJSON() ;

</script>