<script>
    import ButtonGroup from './Group' ;

    export default new ButtonGroup().toJSON() ;

</script>