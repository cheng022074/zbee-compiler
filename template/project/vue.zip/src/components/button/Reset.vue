<template>
    <zb-button type="primary" :zb-view-model="zbViewModel" :zb-root-view-model="zbRootViewModel" :onclick="onclick">重置</zb-button>
</template>
<script>

import {
    EventButton
} from '../Button' ;

export default new EventButton().toJSON() ;

</script>