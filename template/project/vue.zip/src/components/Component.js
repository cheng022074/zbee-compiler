import {
    include
} from '~/../lib/zbee' ;

const copy = include('object.copy'),
      isString = include('is.string');

import ViewModel from '~/utils/model/view' ;

export default class Component{

    get props(){

        let properties = this.generateProperties(),
            result = {
                zbViewModel:{},
                zbRootViewModel:{}
            };

        for(let property of properties){

            if(isString(property)){

                result[property] = {} ;
            
            }else{

                let config = result[property.name] = copy({} , property , [
                    'required'
                ]) ;

                if(property.hasOwnProperty('default')){

                    config.default = () => property.default ;
                }
            }
        }

        return result ;
    }

    generateProperties(){

        return [] ;
    }

    destroyed(){

        let me = this ;

        ViewModel.unregister(me.zbViewModel) ;
    }

    toJSON(){

        return copy({
            methods:{}
        } , this , [
            'props',
            'render',
            'created',
            'destroyed'
        ]) ;
    }
}