<template>
    <el-container>
        <el-header v-if="title">
            <h3>{{title}}</h3>
        </el-header>
        <el-main>
            <el-form label-width="80px"></el-form>
        </el-main>
    </el-container>
</template>
<script>
export default {
    props:[
        'title'
    ]
}
</script>