import Menu from '~/components/Menu.vue';

import Page from '~/components/Page.vue';

import Button from '~/components/Button.vue';

import buttonSave from '~/components/button/Save.vue';

import buttonCancel from '~/components/button/Cancel.vue';

import buttonReset from '~/components/button/Reset.vue';

import buttonSearch from '~/components/button/Search.vue';

import buttonText from '~/components/button/Text.vue';

import buttonGroup from '~/components/button/Group.vue';

import Container from '~/components/Container.vue';

import pageSample from '~/components/page/Sample.vue';


export default {

    install(Vue) {


        Vue.component('zb-menu', Menu);

        Vue.component('zb-page', Page);

        Vue.component('zb-button', Button);

        Vue.component('zb-savebutton', buttonSave);

        Vue.component('zb-cancelbutton', buttonCancel);

        Vue.component('zb-resetbutton', buttonReset);

        Vue.component('zb-searchbutton', buttonSearch);

        Vue.component('zb-textbutton', buttonText);

        Vue.component('zb-buttongroup', buttonGroup);

        Vue.component('zb-container', Container);

        Vue.component('zb-samplepage', pageSample);

    }
}