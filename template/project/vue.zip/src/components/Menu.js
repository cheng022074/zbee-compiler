export default {
    props:{
        menu:{
            default(){

                return [] ;
            }
        }
    },

    render(createElement){

        return createElement('el-menu' , {
            class:{
                'zb-menu':true
            }
        } ,this.menu.map(item =>{

            return createElement('el-menu-item' , {
                props:{
                    index:item.url
                } 
            } ,[
                createElement('router-link' , {
                    props:{
                        to:item.url
                    },
                    domProps:{
                        innerHTML:item.title
                    }
                })
            ]) ;

        })) ;
    }
} ;