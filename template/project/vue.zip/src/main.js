import Vue from 'vue';
import ElementUI from 'element-ui';
import VueHighlightJS from 'vue-highlightjs';
import 'vue-highlightjs/node_modules/highlight.js/styles/vs.css';
import 'element-ui/lib/theme-chalk/index.css'
import router from './router' ;
import Component from './components';
import App from './App.vue';

Vue.use(ElementUI);

Vue.use(Component) ;

Vue.use(VueHighlightJS) ;

new Vue({
  el: '#app',
  router,
  render: h => h(App)
}) ;
