import Vue from 'vue';


import Main from '~/views/Main.vue';

Vue.component('zbview-main', Main);

import mainSampleButton from '~/views/main/sample/Button.vue';

Vue.component('zbview-main-sample-button', mainSampleButton);

import mainSampleEvent from '~/views/main/sample/Event.vue';

Vue.component('zbview-main-sample-event', mainSampleEvent);

import mainSampleModelView from '~/views/main/sample/model/View.vue';

Vue.component('zbview-main-sample-model-view', mainSampleModelView);


export default [{
    "path": "/",
    "redirect": "/main"
}, {
    "path": "/main",
    "component": Main,
    "children": [{
        "path": "button",
        "component": mainSampleButton
    }, {
        "path": "event",
        "component": mainSampleEvent
    }, {
        "path": "model/view",
        "component": mainSampleModelView
    }]
}];