exports['<%- fullName %>'] = function(<%- params %>){

    const {
        $alert:alert,
        $confirm:confirm,
        $prompt:prompt
    } = this ;
    
    <%- requires %>

    <%- imports %>

    <%- configs %>

    <%- extend %>

    <%- code %>
} ;