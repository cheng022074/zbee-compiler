<script>

    import Component from './<%- name %>' ;

    return new Component().toJSON() ;

</script>