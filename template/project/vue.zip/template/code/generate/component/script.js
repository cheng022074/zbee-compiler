import dispatch from '~/utils/model/view/event/dispatch' ;

import Component from '~/components/Component' ;

import ViewModel from '~/utils/model/view' ;

export default class <%- name %> extends Component{

    generateProperties(){

        return [
            // 这里填写属性定义
        ] ;
    }

    render(createElement){

        let me = this,{
            zbViewModel,
            zbRootViewModel
        } = me ;

        // 这里定义模板
        return createElement('div') ;
    }
}