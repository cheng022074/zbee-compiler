import Vue from 'vue' ;

<%
    let names = Object.keys(components) ;

    for(let name of names){
%>
import <%- name %> from '~/views/<%- components[name].path %>.vue' ;

Vue.component('zbview-<%- components[name].tag%>' , <%- name %>) ;
<%
    }
%>

export default <%- routers %> ;