<%
    let names = Object.keys(components) ;

    for(let name of names){
%>
import <%- name %> from '~/components/<%- components[name].path %>.vue' ;
<%
    }
%>

export default {
    
    install(Vue){

        <%
            let aliasNames = Object.keys(aliases) ;

            for(let aliasName of aliasNames){
        %>
                Vue.component('zb-<%- aliasName %>' , <%- aliases[aliasName] %>) ;
        <%
            }
        %>
    }
}