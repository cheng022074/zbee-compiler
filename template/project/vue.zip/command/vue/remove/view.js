/**
 * 
 * 删除指定视图名称的资源
 * 
 * @import {removeFile , writeTextFile} from fs
 * 
 * @import {nameToPath} from string
 * 
 * @import application
 * 
 * @import {NotDefinedException} from exception
 * 
 * @import router from config::browser.router
 * 
 * @import {format} from json
 * 
 * @require {join} from path
 * 
 * @param {String} name 模板名称
 * 
 */

if(!name){

    throw new NotDefinedException('模板名称') ;
}
    
let children = router['/main'].children,
    basePath = nameToPath(name);
    
if(children.hasOwnProperty(basePath)){

    delete children[basePath] ;
}
    
let scopePaths = application.SCOPE_PATHS,
    uiPath = join(scopePaths.ui , `${basePath}.json`),
    vuePath = join(application.PATH , 'src' , 'views' , 'main' , `${basePath}.vue`);

removeFile(uiPath) ;

console.log('已删除' , uiPath) ;

removeFile(vuePath) ;

console.log('已删除' , vuePath) ;

let routerPath = join(scopePaths.config , 'browser' , 'router.json') ;

writeTextFile(routerPath , format(router)) ;

console.log('已重置' , routerPath) ;