/**
 * 
 * 移除一个组件
 * 
 * @import {removeFile , writeTextFile} from fs
 * 
 * @import {nameToPath} from string
 * 
 * @import {NotDefinedException} from exception
 * 
 * @import component from config::browser.component
 * 
 * @import {format} from json
 * 
 * @import application
 * 
 * @param {String} name 组件名称
 *  
 */

if(!name){
    
    throw new NotDefinedException('组件名称') ;
}

if(!component.hasOwnProperty(name)){

    throw new NotDefinedException(name) ;
}

let className = component[name] ;

delete component[name] ;

if(!Object.values(component).includes(className)){

    let codeBasePath = join(application.PATH , 'src' , 'components' , nameToPath(className)),
        vuePath = `${codeBasePath}.vue`,
        scriptPath = `${codeBasePath}.js`;

    removeFile(vuePath) ;

    console.log('已删除' , vuePath) ;

    removeFile(scriptPath) ;

    console.log('已删除' , scriptPath) ;
}

let componentPath = join(scopePaths.config , 'browser' , 'component.json') ;

writeTextFile(componentPath , format(component)) ;

console.log('已重置' , componentPath) ;