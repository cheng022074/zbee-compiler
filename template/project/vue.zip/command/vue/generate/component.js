/**
 * 
 * 创建一个空的组件
 * 
 * @import {NotDefinedException , ExistsException} from exception
 * 
 * @import component from config::browser.component
 * 
 * @import application
 * 
 * @import {capitalize , nameToPath} from string
 * 
 * @require {join , basename} from path
 * 
 * @import {file:is_file} from is
 * 
 * @import {writeTextFile} from fs
 * 
 * @import {format} from json
 * 
 * @param {String} name 组件名称
 * 
 * @param {String} className 实现组件文件全称
 * 
 */

if(!name){
    
    throw new NotDefinedException('组件名称') ;
}

if(!className){

    throw new NotDefinedException('组件代码名称') ;
}

if(component.hasOwnProperty(name)){

    throw new ExistsException('组件') ;
}

let appPath = application.PATH,
    basePath = nameToPath(className),
    codeBasePath = join(application.PATH , 'src' , 'components' , basePath),
    vuePath = `${codeBasePath}.vue`;

if(is_file(`${codeBasePath}.vue`)){

    throw new ExistsException('组件代码') ;
}

let codeName = capitalize(basename(basePath)) ;

writeTextFile(vuePath , apply('code.generate.component.template' , {
    name:codeName
})) ;

console.log('已生成' , vuePath) ;

let scriptPath = `${codeBasePath}.js` ;

writeTextFile(scriptPath , apply('code.generate.component.script' , {
    name:codeName
})) ;

console.log('已生成' , scriptPath) ;

component[name] = className ;

let componentPath = join(scopePaths.config , 'browser' , 'component.json') ;

writeTextFile(componentPath , format(component)) ;

console.log('已重置' , componentPath) ;