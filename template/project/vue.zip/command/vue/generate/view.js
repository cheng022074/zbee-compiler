/**
 * 
 * 通过指定的模板类型创建指定命名模板名称的模板
 * 
 * @import {apply} from template
 * 
 * @import {writeTextFile} from fs
 * 
 * @import {nameToPath} from string
 * 
 * @import application
 * 
 * @import {NotDefinedException , ExistsException} from exception
 * 
 * @import router from config::browser.router
 * 
 * @import {format} from json
 * 
 * @require {join} from path
 * 
 * @param {String} type 模板类型
 * 
 * @param {String} name 模板名称
 * 
 */

 if(!type){

     throw new NotDefinedException('模板类型') ;
 }

 if(!name){

    throw new NotDefinedException('模板名称') ;
 }

let children = router['/main'].children,
    basePath = nameToPath(name);
 
if(children.hasOwnProperty(basePath)){

    throw new ExistsException('页面') ;
} 

 let scopePaths = application.SCOPE_PATHS,
     uiPath = join(scopePaths.ui , `${basePath}.json`),
     vuePath = join(application.PATH , 'src' , 'views' , 'main' , `${basePath}.vue`);

 writeTextFile(uiPath , apply(`code.generate.view.ui.${type}` , {
     name
 })) ;

 console.log('已生成' , uiPath) ;

 writeTextFile(vuePath , apply(`code.generate.view.vue.${type}` , {
    path:basePath   
 })) ;

 console.log('已生成' , vuePath) ;

 children[basePath] = {
    title:name,
    component:`main.${name}`
 } ;

 let routerPath = join(scopePaths.config , 'browser' , 'router.json') ;

 writeTextFile(routerPath , format(router)) ;

 console.log('已重置' , routerPath) ;

