/**
 * 
 * 基于 VUE 控制命令
 * 
 * @import {exec} from child_process
 * 
 * @import {open} from url
 * 
 * @import application_watch from application.code.watch
 * 
 * @import {string:is_string , simpleObject:is_simple_object} from is
 * 
 * @import {capitalizeName , nameToPath , nameToTag} from string
 * 
 * @import {apply} from template
 * 
 * @import {format} from script
 * 
 * @import {removeBorders} from RegExp
 * 
 * @import {writeTextFile} from fs
 * 
 * @import application
 * 
 * @import package from command::package
 * 
 * @require {join} from path
 * 
 * @scoped
 * 
 * @require path
 * 
 * @async
 * 
 * @param {String} command 命令
 * 
 */

 async function main(command){

    switch(command){

        case 'dev':

            compile() ;

            package('zbee') ;

            let locked = false ;

            await exec('npm' , 'run' , 'dev' , result =>{

                if(result.lastIndexOf('webpack: Compiled successfully.') !== -1){

                    if(locked === false){

                        open('http://127.0.0.1:8010') ;
                        
                        locked = true ;
                    }
                }

            }) ;

        case 'build':

            await exec('npm' , 'run' , 'build') ;
    }
 }

 function compile(){

    try{

        compile_router() ;

        compile_component() ;

    }catch(err){

        console.log(err.message) ;
    }

    application_watch('config' , (type , name) =>{

        if(type === 'update'){

            try{

                switch(name){

                    case 'config::browser.component':

                        compile_component() ;

                        break ;

                    case 'config::browser.router':

                        compile_router() ;

                        break ;
                }

            }catch(err){

                console.log(err.message) ;
            }
        }

    }) ;
 }

 const jsonBorderRe = /\"\<%\-(.+?)%\>\"/g,
       borderRe = /\<%\-(.+?)%\>/g;

 function compile_router(){
    
    let components = {},
        routers = removeBorders(JSON.stringify(compile_routes(include('config::browser.router') , components)) , jsonBorderRe),
        path = join(application.PATH , 'src' , 'router' , 'routes.js');

    writeTextFile(path , format(apply('browser.router' , {
        components,
        routers
    }))) ;

    console.log('已编译' , path) ;
 }

 function compile_component(){

    let config = include('config::browser.component'),
        keys = Object.keys(config),
        components = {},
        aliases = {};

    for(let key of keys){

        let component = config[key],
            name;

        if(is_simple_object(component)){

            name = component.component ;
        
        }else{

            name = component ;
        }

        aliases[key] = removeBorders(registerComponent(components , name) , borderRe) ;
    }

    let path = join(application.PATH , 'src' , 'components' , 'index.js') ;

    writeTextFile(path , format(apply('browser.component' , {
        components,
        aliases
    }))) ;

    console.log('已编译' , path) ;
 }

 function compile_routes(routes , components){

    let urls = Object.keys(routes),
        result = [];

    for(let url of urls){

        let route = routes[url],
            component,
            children;

        if(is_string(route)){

            component = registerComponent(components , route) ;
        
        }else if(is_simple_object(route)){

            if(route.hasOwnProperty('redirect')){

                result.push({
                    path:url,
                    redirect:route.redirect
                }) ;

                continue ;
            }

            if(route.hasOwnProperty('component')){

                component = registerComponent(components , route.component) ;
            }

            if(route.hasOwnProperty('children')){

                children = compile_routes(route.children , components) ;
            }
        }

        result.push({
            path:url,
            component,
            children
        }) ;
    }

    return result ;
 }

 function registerComponent(components , component){

    let key = capitalizeName(component) ;

    components[key] = {
        path:nameToPath(component),
        tag:nameToTag(component)
    } ;

    return `<%-${key}%>` ;
 }