/**
 * 
 * @param {ViewModel} button 点击的按钮
 * 
 */

alert('Hello ZBEE') ;