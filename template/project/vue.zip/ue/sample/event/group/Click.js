/**
 * 
 * @param {ViewModel} buttonGroup 点击的按钮组
 * 
 * @param {ViewModel} button 点击的按钮
 * 
 */

 alert(`点击了 ${button.get('text')} 按钮`) ;