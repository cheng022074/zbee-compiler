/**
 * 
 * @param {ViewModel} button 按钮
 * 
 */

 

button.document.find('text' , 'Hello').set('type' , 'primary') ;