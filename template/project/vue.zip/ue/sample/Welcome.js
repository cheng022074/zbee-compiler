/**
 * 
 * @param {ViewModel} button 点击的按钮
 * 
 * @param {Object} query 查询参数
 * 
 */

alert('欢迎使用 ZBEE Element UI 开发系统') ;

console.log(query) ;