/**
 * 
 * @import compile_script from code.script
 * 
 * @import param_codes from code.script.function.params
 * 
 * @param {SourceCode} sourceCode 源代码对象
 * 
 * @return {String} 编译后的代码字符串
 * 
 */

let {
    params
} = sourceCode.meta;

return compile_script(sourceCode , 'code.package.script.function.vue.listener' , {
    params:param_codes(params)
}) ;